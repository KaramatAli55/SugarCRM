<?php
// created: 2017-08-16 10:51:27
$dictionary["key1_Course_Management"]["fields"]["key1_course_management_key1_student_management"] = array (
  'name' => 'key1_course_management_key1_student_management',
  'type' => 'link',
  'relationship' => 'key1_course_management_key1_student_management',
  'source' => 'non-db',
  'module' => 'key1_student_management',
  'bean_name' => 'key1_student_management',
  'vname' => 'LBL_KEY1_COURSE_MANAGEMENT_KEY1_STUDENT_MANAGEMENT_FROM_KEY1_COURSE_MANAGEMENT_TITLE',
  'id_name' => 'key1_cours3ce6agement_ida',
  'link-type' => 'many',
  'side' => 'left',
);
