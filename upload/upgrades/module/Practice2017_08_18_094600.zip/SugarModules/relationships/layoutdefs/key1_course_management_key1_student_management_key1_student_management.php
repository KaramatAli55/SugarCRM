<?php
 // created: 2017-08-16 09:37:18
$layout_defs["key1_student_management"]["subpanel_setup"]['key1_course_management_key1_student_management'] = array (
  'order' => 100,
  'module' => 'key1_Course_Management',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_KEY1_COURSE_MANAGEMENT_KEY1_STUDENT_MANAGEMENT_FROM_KEY1_COURSE_MANAGEMENT_TITLE',
  'get_subpanel_data' => 'key1_course_management_key1_student_management',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
