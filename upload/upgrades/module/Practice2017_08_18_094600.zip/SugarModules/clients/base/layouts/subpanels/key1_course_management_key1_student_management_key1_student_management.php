<?php
// created: 2017-08-15 18:10:33
$viewdefs['key1_student_management']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_KEY1_COURSE_MANAGEMENT_KEY1_STUDENT_MANAGEMENT_FROM_KEY1_COURSE_MANAGEMENT_TITLE',
  'context' => 
  array (
    'link' => 'key1_course_management_key1_student_management',
  ),
);

$viewdefs['key1_student_management']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_KEY1_COURSE_MANAGEMENT_KEY1_STUDENT_MANAGEMENT_FROM_KEY1_COURSE_MANAGEMENT_TITLE',
  'context' => 
  array (
    'link' => 'key1_course_management_key1_student_management',
  ),
);