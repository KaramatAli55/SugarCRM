<?php
// created: 2017-08-15 15:29:22
$viewdefs['key1_Course_Management']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_KEY1_COURSE_MANAGEMENT_KEY1_STUDENT_MANAGEMENT_FROM_KEY1_STUDENT_MANAGEMENT_TITLE',
  'context' => 
  array (
    'link' => 'key1_course_management_key1_student_management',
  ),
);

$viewdefs['key1_Course_Management']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_KEY1_COURSE_MANAGEMENT_KEY1_STUDENT_MANAGEMENT_FROM_KEY1_STUDENT_MANAGEMENT_TITLE',
  'context' => 
  array (
    'link' => 'key1_course_management_key1_student_management',
  ),
);

$viewdefs['key1_Course_Management']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_KEY1_COURSE_MANAGEMENT_KEY1_STUDENT_MANAGEMENT_FROM_KEY1_STUDENT_MANAGEMENT_TITLE',
  'context' => 
  array (
    'link' => 'key1_course_management_key1_student_management',
  ),
);

$viewdefs['key1_Course_Management']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_KEY1_COURSE_MANAGEMENT_KEY1_STUDENT_MANAGEMENT_FROM_KEY1_STUDENT_MANAGEMENT_TITLE',
  'context' => 
  array (
    'link' => 'key1_course_management_key1_student_management',
  ),
);