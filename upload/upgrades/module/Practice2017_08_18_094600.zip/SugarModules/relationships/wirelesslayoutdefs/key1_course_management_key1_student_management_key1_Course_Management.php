<?php
 // created: 2017-08-16 10:51:27
$layout_defs["key1_Course_Management"]["subpanel_setup"]['key1_course_management_key1_student_management'] = array (
  'order' => 100,
  'module' => 'key1_student_management',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_KEY1_COURSE_MANAGEMENT_KEY1_STUDENT_MANAGEMENT_FROM_KEY1_STUDENT_MANAGEMENT_TITLE',
  'get_subpanel_data' => 'key1_course_management_key1_student_management',
);
